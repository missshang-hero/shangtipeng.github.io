
import '@styles/set.less'
import userManage from './sys/userManage'
import roleManage from './sys/roleManage'
import moduleManage from './sys/moduleManage'

export { userManage, roleManage, moduleManage }
