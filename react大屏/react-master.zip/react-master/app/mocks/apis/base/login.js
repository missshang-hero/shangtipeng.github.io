
module.exports = {
  data: {
    ticket: 'ticket',
    token: '11111',
  },
  msg: '操作成功',
  status: 1,
}
