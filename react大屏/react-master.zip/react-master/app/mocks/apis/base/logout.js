
module.exports = {
  data: {
  },
  msg: '退出成功！',
  status: 1,
}
