const login = require('./login')
const logout = require('./logout')
const staff = require('./staff')
const menu = require('./menu')

module.exports = { login, logout, staff, menu }
