export const HOST = "/music";
export const API = "/music";